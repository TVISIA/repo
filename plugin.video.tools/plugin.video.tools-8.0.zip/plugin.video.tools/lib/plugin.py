# -*- coding: utf-8 -*-
import xbmc,xbmcaddon,xbmcgui,xbmcplugin,os,sys,xbmcvfs,time,routing,requests, codecs, epg, scripts
from xbmcgui import ListItem
from xbmcplugin import addDirectoryItem as add
from xbmcplugin import endOfDirectory as end
addon = xbmcaddon.Addon()
plugin = routing.Plugin()
dialog = xbmcgui.Dialog()
PY2 = sys.version_info[0] == 2
transPath = xbmc.translatePath if PY2 else xbmcvfs.translatePath
if PY2:
	from urllib import urlretrieve
else:
	from urllib.request import urlretrieve

@plugin.route('/')
def index():
	add(plugin.handle, plugin.url_for(bundle),ListItem("Build installieren"), True)
	#add(plugin.handle, plugin.url_for(setup),ListItem("Pvr update"), True)
	add(plugin.handle, plugin.url_for(renew),ListItem("Premium update"), True)
	add(plugin.handle, plugin.url_for(ftp),ListItem("FTP SERVER"), True)
	add(plugin.handle, plugin.url_for(speedtest), ListItem("Speedtest"), True)
	add(plugin.handle, plugin.url_for(showIp), ListItem("IP anzeigen"), True)
	add(plugin.handle, plugin.url_for(repotest),ListItem("Repos testen"), True)
	add(plugin.handle, plugin.url_for(beenden),ListItem("Beenden"), True)
	add(plugin.handle, plugin.url_for(buffer), ListItem("Buffer fix"), True)
	add(plugin.handle, plugin.url_for(cleanthumbs, False), ListItem("Thumbs entfernen"), True)
	add(plugin.handle, plugin.url_for(skinrestore),ListItem("Skin restore"), True)
	#add(plugin.handle, plugin.url_for(proxy),ListItem("Proxy"), True)
	#add(plugin.handle, plugin.url_for(kodiIp), ListItem("IP renew"), True)
	add(plugin.handle, plugin.url_for(ReloadSkin), ListItem("ReloadSkin"), True)
	add(plugin.handle, plugin.url_for(setmenu), ListItem("ALLE-EINSTELLUNGEN"), True)
	end(plugin.handle)

@plugin.route('/setmenu')
def setmenu():
	add(plugin.handle, plugin.url_for(settings, id="plugin.video.tools"), ListItem('plugin.video.tools-EINSTELLUNGEN'), True)
	home_path = os.path.join(transPath('special://home'),'addons')
	xbmc_path = os.path.join(transPath('special://xbmc'),'addons')
	addonids=[]
	for dirname in os.listdir(home_path):
		if os.path.isfile(os.path.join(home_path,dirname,"resources","settings.xml")):
			addonids.append(dirname)
	for addonid in os.listdir(xbmc_path):
		if os.path.isfile(os.path.join(xbmc_path,dirname,"resources","settings.xml")):
			addonids.append(dirname)
	for newaddonid in addonids:
		if newaddonid != 'plugin.video.tools':
			add(plugin.handle, plugin.url_for(settings, id=newaddonid), ListItem(str(newaddonid.lower()+'-EINSTELLUNGEN')), True)
	end(plugin.handle)
	
@plugin.route('/settings/<id>')
def settings(id):
	xbmcaddon.Addon(id).openSettings()

@plugin.route('/speedtest')
def speedtest():
	xbmc.executebuiltin('Runscript("special://home/addons/plugin.video.tools/lib/speedtest.py")')
	
@plugin.route('/repotest')
def repotest():
	repos=["repository.castagnait","repository.fayer3","repository.kodinerds","repository.sandmann79.plugins","repository.slyguy","repository.xstream"]
	addons= ["plugin.video.dazn","plugin.video.joyn","plugin.video.magenta-sport","plugin.video.rtlgroup.de","plugin.video.vavooto","plugin.video.waipu.tv","plugin.video.xship","plugin.video.xstream","plugin.video.zappntv","script.module.slyguy","slyguy.dependencies","slyguy.disney.plus"]
	for addon in repos:
		xbmc.executebuiltin('InstallAddon(%s)' % (addon))
		xbmc.executebuiltin('SendClick(11)')
	xbmc.executebuiltin("UpdateAddonRepos")
	xbmc.executebuiltin('UpdateLocalAddons')
	for addon in addons:
		xbmc.executebuiltin('InstallAddon(%s)' % (addon))
		xbmc.executebuiltin('SendClick(11)')
	#import repotest
	#xbmc.executebuiltin('ActivateWindow(pvrsettings)')

@plugin.route('/ReloadSkin')
def ReloadSkin():
	xbmc.executebuiltin('ReloadSkin')
	
@plugin.route('/buffer')
def buffer():
	scripts.advancedSettings()
		
@plugin.route('/ftp')
def ftp():
	scripts.show()
    
@plugin.route('/beenden')
def beenden():
	os._exit(1)
	
@plugin.route('/showIp')
def showIp():
	a = requests.get('https://api.myip.com/').json()
	ext_ip = a['ip']
	ok = dialog.ok('Externe IP-Adresse (WAN)', ext_ip)

@plugin.route('/cleanthumbs/<yesnowindow>')
def cleanthumbs(yesnowindow):
	force = False
	if not yesnowindow:
		yesnowindow = dialog.yesno('TOOLS', "Clean all Thumbs")
	if yesnowindow:
		force = True
		for root, dirs, files in os.walk(transPath('special://profile/Thumbnails/')):
			for name in files:
				os.remove(os.path.join(root, name))
		for root, dirs, files in os.walk(transPath('special://home/addons/packages/')):
			for name in files:
				os.remove(os.path.join(root, name))
		if not force:ok = dialog.ok('', 'Fertig')
			
@plugin.route('/proxy')
def proxy():
	scripts.check_proxy()
			
@plugin.route('/bundle')
def bundle():
	yesnowindow = dialog.yesno('TOOLS', 'Build installieren?')
	if yesnowindow:
		scripts.get_packages()
		
@plugin.route('/kodiIp')
def kodiIp():
	yesnowindow = dialog.yesno('TOOLS', "Neue Ip?")
	if yesnowindow:
		a = requests.get('https://api.myip.com/').json()
		alt_ip = a['ip']
		con = scripts.connect_mobile
		dis = scripts.disconnect_mobile
		ctx = scripts.quick_login(addon.getSetting('user'), addon.getSetting('passw'))
		dis(ctx)
		con(ctx)
		time.sleep(10)
		try:
			a = requests.get('https://api.myip.com/').json()
			neu_ip = a['ip']
			ok = dialog.ok('Tool', 'Alte IP = '+alt_ip, 'Neue IP = '+neu_ip)
		except:
			try:
				time.sleep(5)
				a = requests.get('https://api.myip.com/').json()
				neu_ip = a['ip']
				ok = dialog.ok('Tool', 'Alte IP = '+alt_ip, 'Neue IP = '+neu_ip)
			except:
				time.sleep(5)
				a = requests.get('https://api.myip.com/').json()
				neu_ip = a['ip']
				ok = dialog.ok('Tool', 'Alte IP = '+alt_ip, 'Neue IP = '+neu_ip)
		
@plugin.route('/skinrestore')
def skinrestore():
	scripts.restore()

@plugin.route('/renew')
def renew():
	scripts.premium()

"""
	urlretrieve(addon.getSetting('prem2'), transPath('special://home/userdata.zip'))
	time.sleep(2)
	xbmc.executebuiltin('Extract("special://home/userdata.zip")')
	time.sleep(2)
	xbmcvfs.rmdir('special://home/userdata.zip', force=True)
	urlretrieve(addon.getSetting('prem'), transPath('special://home/userdata.zip'))
	time.sleep(2)
	xbmc.executebuiltin('Extract("special://home/userdata.zip")')
	import xml.etree.ElementTree as ET
	xbmcvfs.mkdir('special://home/mist/')
	zip = transPath('special://home/mist/backup.zip')
	urlretrieve(addon.getSetting('prem'), zip)
	xbmc.executebuiltin('Extract("special://home/mist/backup.zip")')
	time.sleep(2)
	if xbmc.getCondVisibility('System.HasAddon("plugin.video.rtlnow")'):
		data = ET.parse(transPath('special://home/mist/userdata/addon_data/plugin.video.tvnow.premium/settings.xml')).getroot()
		tvnowuser = data.find(".//*[@id='email']").text
		tvnowpass = data.find(".//*[@id='password']").text
		xbmcaddon.Addon('plugin.video.rtlnow').setSetting('user',tvnowuser)
		xbmcaddon.Addon('plugin.video.rtlnow').setSetting('pass',tvnowpass)
	if xbmc.getCondVisibility('System.HasAddon("slyguy.disney.plus")'):
		data = ET.parse(transPath('special://home/mist/userdata/addon_data/plugin.video.disney.plus/settings.xml')).getroot()
		disneyuser = data.find(".//*[@id='_userdata']").text
		xbmcaddon.Addon('slyguy.disney.plus').setSetting('_userdata',disneyuser)
	if xbmc.getCondVisibility('System.HasAddon("plugin.video.waipu.tv")'):
		data = ET.parse(transPath('special://home/mist/userdata/addon_data/plugin.video.waipu.tv/settings.xml')).getroot()
		waipuuser = data.find(".//*[@id='username']").text
		waipupass = data.find(".//*[@id='password']").text
		xbmcaddon.Addon('plugin.video.waipu.tv').setSetting('username',waipuuser)
		xbmcaddon.Addon('plugin.video.waipu.tv').setSetting('password',waipupass)
	xbmcvfs.rmdir('special://home/mist/', force=True)
	xbmcvfs.rmdir('special://profile/addon_data/plugin.video.dazn', force=True)
	xbmcvfs.rmdir('special://profile/addon_data/plugin.video.joyn', force=True)
	urlretrieve("http://michaz1988.000webhostapp.com/userdata.zip", transPath('special://home/userdata.zip'))
	xbmc.executebuiltin('Extract("special://home/userdata.zip")')
	if dialog.ok('Tool', 'Fertig!'):
	xbmcvfs.rmdir('special://home/userdata.zip', force=True)
"""

@plugin.route('/forceIp')
def forceIp():
	con = scripts.connect_mobile
	dis = scripts.disconnect_mobile
	ctx = scripts.quick_login(addon.getSetting('user'), addon.getSetting('passw'))
	dis(ctx)
	con(ctx)
	
@plugin.route('/setup')
def setup():
	cleanthumbs(yesnowindow=True)
	renew()
	dialog.notification('TOOLS', 'Starte EPG Aktualisierung', xbmcgui.NOTIFICATION_INFO, 2000)
	m3uPath = 'special://profile/addon_data/plugin.video.tools/channels.m3u'
	german = 'resource.language.de_de'
	xml = '<settings version="2">\n    <setting id="m3uPathType">0</setting>\n    <setting id="m3uPath">'+m3uPath+'</setting>\n    <setting id="m3uUrl" default="true" />\n    <setting id="m3uCache" default="true">true</setting>\n    <setting id="startNum" default="true">1</setting>\n    <setting id="numberByOrder" default="true">false</setting>\n    <setting id="m3uRefreshMode" default="true">0</setting>\n    <setting id="m3uRefreshIntervalMins" default="true">60</setting>\n    <setting id="m3uRefreshHour" default="true">4</setting>\n    <setting id="epgPathType">0</setting>\n    <setting id="epgPath">special://home/userdata/addon_data/plugin.video.tools/epg.xml</setting>\n    <setting id="epgUrl" default="true" />\n    <setting id="epgCache" default="true">true</setting>\n    <setting id="epgTimeShift" default="true">0</setting>\n    <setting id="epgTSOverride" default="true">false</setting>\n    <setting id="useEpgGenreText" default="true">false</setting>\n    <setting id="genresPathType" default="true">0</setting>\n    <setting id="genresPath" default="true">special://userdata/addon_data/pvr.iptvsimple/genres/genreTextMappings/genres.xml</setting>\n    <setting id="genresUrl" default="true" />\n    <setting id="logoPathType" default="true">1</setting>\n    <setting id="logoPath" default="true" />\n    <setting id="logoBaseUrl" default="true" />\n    <setting id="logoFromEpg" default="true">1</setting>\n    <setting id="timeshiftEnabled">true</setting>\n    <setting id="timeshiftEnabledAll" default="true">true</setting>\n    <setting id="timeshiftEnabledHttp" default="true">true</setting>\n    <setting id="timeshiftEnabledUdp" default="true">true</setting>\n    <setting id="timeshiftEnabledCustom">true</setting>\n    <setting id="catchupEnabled" default="true">false</setting>\n    <setting id="catchupQueryFormat" default="true" />\n    <setting id="catchupDays" default="true">5</setting>\n    <setting id="allChannelsCatchupMode" default="true">0</setting>\n    <setting id="catchupPlayEpgAsLive" default="true">false</setting>\n    <setting id="catchupWatchEpgBeginBufferMins" default="true">5</setting>\n    <setting id="catchupWatchEpgEndBufferMins" default="true">15</setting>\n    <setting id="catchupOnlyOnFinishedProgrammes" default="true">false</setting>\n    <setting id="transformMulticastStreamUrls" default="true">false</setting>\n    <setting id="udpxyHost" default="true">127.0.0.1</setting>\n    <setting id="udpxyPort" default="true">4022</setting>\n    <setting id="useFFmpegReconnect" default="true">true</setting>\n    <setting id="useInputstreamAdaptiveforHls" default="true">false</setting>\n    <setting id="defaultUserAgent" default="true" />\n    <setting id="defaultInputstream" default="true" />\n    <setting id="defaultMimeType" default="true" />\n</settings>'
	if not xbmcvfs.exists('special://profile/addon_data/pvr.iptvsimple/'):
		addon.setSetting('aktuell', 'erster Start bitte warten')
		try:
			xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format(german))
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"epg.futuredaystodisplay", "value":2}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"epg.epgupdate", "value":120}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"videoplayer.teletextenabled", "value":false}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrplayback.signalquality", "value":false}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrplayback.confirmchannelswitch", "value":false}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"locale.language", "value":"resource.language.de_de"}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"locale.keyboardlayouts", "value":"German QWERTZ"}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"locale.activekeyboardlayout", "value":"German QWERTZ"}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"epg.futuredaystodisplay", "value":2}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"locale.country", "value":"Deutschland"}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"pvrmanager.preselectplayingchannel", "value":true}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"filelists.showhidden", "value":true}, "id":1}')
			xbmc.executeJSONRPC('{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"filelists.allowfiledeletion", "value":true}, "id":1}')
		except:ok = dialog.ok('', 'Fuck irgendwas ist schiefgelaufen')
	xbmcvfs.mkdirs('special://profile/addon_data/pvr.iptvsimple/')
	set = transPath('special://profile/addon_data/pvr.iptvsimple/settings.xml')
	with codecs.open(set, 'w', encoding='utf8') as f:
		f.write(xml)
	addon.setSetting('aktuell', 'aktualisierung in gange')
	epg.newepg()
	
def run():
    plugin.run()