
def init():
	global aDirectory
	global urlparams
	global collectMode
	aDirectory = []
	urlparams = {}
	collectMode = False