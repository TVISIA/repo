# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, os, sys, hashlib, re, time, json, six, xbmcvfs
from datetime import datetime,date,timedelta
from resources.lib import common, pyaes, settings
from six.moves.urllib.parse import quote, unquote, quote_plus, unquote_plus, urlparse, urlencode
from six.moves.html_entities import name2codepoint

addon = xbmcaddon.Addon()
addonInfo = addon.getAddonInfo
addonID = addonInfo("id")
addonName = addonInfo("name")
get_setting = addon.getSetting
set_setting = addon.setSetting
api_key="86dd18b04874d9c94afadde7993d94e3"
tmdburl = "https://api.themoviedb.org/3/"
tmdbimg = "https://image.tmdb.org/t/p/%s%s"
translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath

def py2dec(msg):
	if six.PY2:
		return msg.decode("utf-8")
	return msg

def translate_path(*args):
	return py2dec(os.path.join(*args))

addonPath = common.addonPath
profilePath = common.profilePath

if not os.path.exists(profilePath):
	os.makedirs(profilePath)

def handle():
	return int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1

def selectDialog(list, heading=None, multiselect = False):
	if heading == "default" or heading is None:
		heading = xbmcaddon.Addon().getAddonInfo("name")
	if multiselect: return xbmcgui.Dialog().multiselect(str(heading), list)
	return xbmcgui.Dialog().select(str(heading), list)

home = xbmcgui.Window(10000)

def set_cache(key, value, timeout=300):
	data={"sigValidUntil": int(time.time()) +timeout,"value": value}
	home.setProperty(key, json.dumps(data))
	
def get_cache(key):
	keyfile = home.getProperty(key)
	if keyfile:
		r = json.loads(keyfile)
		if r.get('sigValidUntil', 0) > int(time.time()):
			return r.get('value')
		home.clearProperty(key)
	return

def getAuthSignature():
	signfile = get_cache('signfile')
	if signfile: return signfile
	import requests, random
	sig = None
	veclist = [
		"eVllPXmUruGG5JPG8cZOiIbXbVNnyXv80GxNj0yQZed3z2iQlV5ukkyaHBpJ2Xw0XHl124wH5XT6eyb0xQdYDOpNHRCYCOgU9L5+c/Q21kZU+vUZJN7VCGgAhJgE9GfXSIq/mDSsKmczVj4g/8prBZOGCreE0uwN9K/6lwhlIFMpG2w9OYkUJaXIDALcGWc61wfZEj/uFZsDs7ci7h9NqSmY0wU82jwH11jK5/qeCElin8B6fhCXMOEzPURNOs4Mr4eeFQBwCzwuUTil+BjE2nSiYTlvURkBkxr99WseUp/xV96JtaKtep/qiwq2oU4eFEH1cT90M1IjwHqjNFBXp6FNd+A+Dfbv4iJS3AWaVX4t+aBDM7mCDkNrWc29qwcHipoxiuW0UPSphOaWGYq1eM254QNOFH4s4FCT8qid0y5fWmxy5foWYUvb0ZVq4WywOPNb1KPPofHsZ5aATaXAMUB/CORKM5AbynKd+6C+E7tRY5TbZAq1I7FNwjEKD5JGGczlSMbp+Av4YQI69p/bV6vwZtqyNBSkzwUyj/0q+1vj5d3rcIM5jujo106g6ocI5KVjfPUiiFQyvEiNL/fw2CtPFyqjXdyY3uKjdRWWt0LZCFN/0pehgFi25CyMe35O3mSiLoC6eT4evDa/BJRssk3pIY5auUNFYOFi3VVl6MEqcv1fLzXZiydtjjo6CpUUcxnkHLY4KsRjB0G/FttKI+GyT2XvwsHqGk2glDKmUu2IsMXhzNYIVBlbwOXDJ2il4TzViYIlEAkV1oG2KInkn473MOIS/ts4FD+1LGBbGjuWJST2TDp++ZavPkkkSBOM45/GO8Yl2DBCy4jIsUHcN04INBUCOIiFEphyzY/Sq9N1ZiEIkZPl6ZZAt863xzjjc4sIxl47sD8sQ03hjQi/dzMhZUJYOwe1qsLWZwWn2gUJ5fAr/4EQK9K3fDnSBbPDGrdy/ooUbIOLXW9vRDEKlv/Uy+/jTCjhzaSiNcziYVx92LNSrEoKBfK7cF0OS390WI3LtgcNDYlmubyaIS0+OMKHViEocJtFhH/hwq5yiI4VgKF+V69EJ0R/hTXJGRUMFsYOKimQWVl6YWssurx54xkoXev46FaTtwRCk+X1yQmgi8cKdRdKzquMVNIhzaBBGmjKM7Pj39MCT9MiyYT+GBO8AB7KIFv5srjKx7xkjIeVyl70pMo6gQagn3uWArGFOgSGJ0RZ+1araq04YFt0GY3y4ldu6CuKhepJbP2K/ndEAuj00X4F6AjZbwOD+1t4vRpIKhw3y9cJvCJ3pbPpeNgU8AtwijvsOUHuomVjS7H0sUx3ryzwMO/Cbccivfki+5dCvtVf6r6pudkTdas+6tR9RNj83JJPesEvBuMYKTUxzJdtw4Yh/y7p7jUmvbZvlV8Pp+bu6epT74Aj0+TeZNtIKCICMOydNiT7x3K0BLuxkxAnZZ4b2+2nxReiclj06SbsJnZEfs7Ke28HD11AK7rcl6Wdp3/gSeA5duVDOvV2iQKCaS0nR02Bs6CGDPUdxPgjD7QMLfMo6bBzc5CsUYZU3Q0eqRtB9kVS5tGeLvxWkSEZwfeUZ3KVtjecNtl/k1UfrQtAdfn7GWVG6pSxw9F7iLjLo2lgiKE58kzGOrxiBCzgexNRZLNInqrKqZ4K0bStVNNSKtVYxaULA1lqhBidsBLWJlU0PYCsia4XUggB4EVvKQB0F6pWUvytrfzKxJoOZSipKBNsmQIGtA4rJsO5hzzTy+anrNGqar4ewzgnOO2vp0FffljLP/NaqXBMKcr7fGhFWpXXSj/syW/qWNV0VSKVM1fv478OMzfbSpONoX93+lqfqMQFocinpz1CCzGnwlEHZYEkuGf1xX/9pMnDJtVtuyDY3Kb4GBo7ksAXCdesBVaiPdGQDYbG5A6aNsjy/x/Xuy8/smhArnTj0AlEIvIPFW5YEXEPimOCxuCOxRl/gDFfDmb3vDCpp9ju",
		"ITMga159XwWsPhw68P/VY25OsX5cjqNRvGGBDbgppJSfF0LNvWduzI/4gD4V5CoQKe33qKd9JURpHycV9CcqvoSzeuAf+QMiY6O9EfaVqSE8qHvHi+mMwqZLLCRtcetH9ycbRIiIMh/zis0BxcgJLTp9T0l375oYJKOnLFYb/GrqCByQQpCFNLWJNpzEfeEpqaZwrrj1xoEfQqGQIe2x4/R2oT2WGQKiF7jJuNgqtgZwiVeMh46/6vEo0SAHsFTbaFUCR7POPbHvRnCr/72H4apgqDlfYO9zm8cMq0OWkrnIYPA+TngXvSGCD5TM+L+EUz+4271NXQ3Bsty4AT4K4u+oI7SwVQAL4hNoY3Xna5Y1YF0k687i4Q3Gkh6qRBzWYvhxHpr1Uf2pZNGu3b4q313N7TfZNRwK6d1avYk3iHtmlvd4XYel6VeYryRzAiONeQ+Nry3Z9V/Difz60mttItTo9uZyW8z5npSGlNsa62qG1zQVE+3+kHVAsP3Res1lJ8DNXHb9EbNv4KfeZfNZrJgwVdJgQukbvvv/F9TfMxmoG0NiQ2xKNkFyjXx66KSRHmd+p9BXqYU8shargzTFDTofMrGoQg0mUdrJm9ucePNi/ml7wgVxsSBb70Bri1YBN4nC3R28a0FVfEb9yrItRI3OB9r1l1XI82VzPEd+A1Jpcpc/Qgf95J35x88s1uNxZbcopAAKvB+mVKvM9w/CLTkdiNV34vc2QFsA4hyVq0n6Mt+KuWbbqXWAy7+YEiHSVVOT+LHkqlV30bGUjBz9XTX+lUo/zuFokQlWW1NMsJWLGPloZETkvFrLxXjoBK3Ja+dccjGAjV+YkgJVOvu5fiXoRI4jyb3PDB3zzKt7e/IwfVwPEW5CiF9HRRGLv+KKFeqkq+bbY6u2n40Kzdvv+Rih4iveQ/Z82OYKiWSZfB6wIH5z+myvH1LdWaupi7lh662G4+6ztP6bFqWzSgVJhIFsdZDyhpjz4f3rTtl5u9G7FNVm9gn3qD3m95+gi24XfY2DHF7pnAQP7sPjkNM8epuD+tFpQNKg53r2tv6c9CZtTo6V0Fq5/ZfkqVgpi/c1ypNFBXto15IXm0PVJJk9idsEIXuQZV6OygvDPuIU+cQdj9Lfak08OoDpsdrRPdSeffqJVZn2t+aQnnLJ1FcMng1XjTBYOf4Xsl6rjtbbLyRM2haVJSf9nFupDCZky/j7c1BVK0C2shNJXrQaG+5iqQT8WOMvBx9iRbVt2XRpDKI5B1ImD9F2+wF7/byJJvbVuF6wGOMuRuJu8oEhl+sUV/36ZQaNxm45T5Cu1CueAvApqzjYAfTlR44sTjZxqN86GIxnmgjhiqje3R0EB3mFQKd96ZBs3apdoeiCo8S/cCwL96P0/0pw0SWJZ1/htkh25L5PLeYZZMT4s1ELxNoxBt2xqJq0glYIrRHIc6nRpkVu1WCz5eluucJGHqjdG96NBFIa6qh/+vcHyNasMYcg8b6HsFR3+jGHWNvN0tT4ISZPcmP8xLTR8xZ8eidmlKCMfAWC0x1YqvPTnikqT1WD4jlAVOjMUQcfBshQw3vzk/rgQ1E/yIaxW0N1V0CyHP8bR39Y6EOujzilUSQUQoEDHYqmsuep+rJ5WPqDKVPIR5rRA7URMXXnwqJ4u9+9QdVNL1JnoCnIvCiKDMwYZzS+io0AiPWDGtjxUX55mBtS1R8zYeA6F//zmlgbgGCO0FfatXeaFLz7Lf2iGu9CqisPiEUZVDqajJORV7KwMAJvVQfnyXJ7HRPIWN3mV9jC8u0Y/KCRysADVp0tq/MmmPcqcl9ZTHjuNcWyYDzaWQIiCQo211f6xAlk7iTAKDDlmRKB7F8mLVv1z9NISNoXgGsgtkD4gBx04dE9q6orHpeZE0gUY+J71QAtUbCHOs+qRX6fnUAIv/5aqu7rPoYHz9dLRdDc4sZAcwj41s2Gs4wTrDDalGmR8Kutbk95+675noY0",
		"gerKZZjYV92n3HbWxYG9U92d5QIA2NZbD/ur5LNUe1ldDQf3FESG0swidJPcOdGZF+CVxeb7l5I8ccZz6FdCfEZ6rs3m96uIEeJcQusw+HJl0X9j7UWVee621ZUpQUWS6UYkb+ijMweuwvLL349BPTKyC90HhQlqw/S78O0+RrCiAM14M4h5SPZo+ZytYNnVqk5AYN0zwEPZprO4pYzHyR4yC2+X7Fqlgmdy4T8VE5/Bgr0/b+eHo2Odg9Tdo2GCaQjIM+lASOuY3CTAe/Wu9ThyUdJskdma2tq1K0aktE4+ORm3L7+0rSUXptI1xnY8GH+NUplYJEK4NBj/6KkQ8joKXVK6D997Toh6RgCHAnVlb8OWEM4YuCK+QjotPzh0TXl5+HsH3XBwISLuVG+bT09hq8CjBFfgZA0QBu8bfTyk2yG64Qcq4t9uDPKIxa+h0jg5U2sowxAnwu4mKOJcb3bnjqghxIIFMA9p5RgZ5FeW4M7InAXd4RSmCmFgheFWlUs4IvQFabuPD2MpXzLMD60a+rKjrqD9/gSev/6wHxBYpzfcwoYvTMHVK8GlKF7sxPML3vdY4G1OYOXN6b69QhPN3p2KFBCp8haqcIp77SfWzusX+YPIjDfPKnW8HnVudCVdYieYuHjYfm+m2WRqfcqKeOoOZkoDiIdJi4doAEr0RZT3XbqfydwTXSTjKFqZifk625PFyRQiV5Ka7RdsouONDMYHBVjmbnlo69F3VVJ0wISAupOXxNTgViy1uuLTZStFwIoBL/R9vFxsl2afShNs6c69gV9hQrdnjQ9+4X44RxH9lz0rtZi0Z/CdutjdHEXRZRTgump2FjsHOgjgcxXxXxGugH+uwhu5a+NDL6Vnk2PChTDuecV6VljPMQ7ztiREXyllbRDLZ6w1NEeVSmsuZ0DXyH1u2zy5pg/1JGgn+pqdGLuZMhJ2aIMxe+wycmU4jeACTEyOElanQ1xs3hfmi/bNXKFR/GJNNCRapKHADOO6GSpOCt4BBT00UGkDkazXFZ1qVFBolRsYvg/0iFwsoSeWEvmMAspP68pF4D4frkfPTOkrKNuOPWSSp6uyis0TcwR283a77mjM/qa/UpKi4fcHsiGnORMYD2WXEmYr+S3xK2ckeZ+62Shzyu167kCpDuL2J4aQ7d5zVoXBjacbELsoRdHo1GZuCwRjDKPOsA5IgZ9mGZ3sY2eBE4NCQ9T0IxYHE/g+j2g/ICYgKYO8jZL4a3MQcdncm5mnLH8EdLOKX9Bi1gy/jHNBfnwo+ndaTZ2JZKcVqZGiTmBrgQ6hFe5LWCv3jsfslHUSbcZVs7QXPuvZNg6rBmJqXuzylp2wrgNeyGfI8/x3bc6NfXW0HMHia3ZBaPaWC38yq6WvEes6Mm7KbT4fmwNMT9G5UiiRNx3VdU5SrhYILFF9mwZjxOi1tvOazVWsfzFgT5rC0BUgNCXitraHXVTeNX7I3ApeNaHGfR4yBvLAXzc0X7sLgRXClBzQDDGOsUN8C0YkxK0cFPeCvPZ03yac37OJT+DBwbYd8RnD+3b8UFjkY6T7q084E5tUvNoD2vSYuKWhCLTVon3RXtbh1N59NPNf+/1S9w/XIekn1w3MGqCpH6Gw2vTDlPTBQMdip+jnHT3Ch6yOfb8BCAQ/cWm80zyIJgr4Xp2YCUJeV7UzV5PvzDFpScDcQLbSjfwdNMloJiW054Hsb7sY8lL+9RGCX8TJeU6+xPhsOliLUQc4iHgC06d42AK+aGMou2FJBAqotu1sgr8wPkvdCrEaNeiwREJQO2HbMrnx5XbviYtcGFjWYP8uWb26dKgDwR1fqHbhNQYKxT40gQ+GiTRO+w9KotBBII88fKINmn3KWf9EG7CSvTgY5VXzmtiLrEZ05WRGn1vskH9hEc+QIaD21Ob+AzUoAaG6ZPilif1ZO8H7JpH+34SZjYpiSzc9hcN9PPtg9N03CmepS3VMi3EjoO4DWqiO",
		"9YshEOdiid7fyzMkI5tZcWJtJrZk6kgFzPlU0iU0eCEoiKxWlJl5yQ6FGstitQ093l3gIaYX7O3DBmlEcOcYhieBLzcOd8AmSmoZUJklZidXH72CASaZaycVN5j6Q/CM4aBH9q66z3/hwvgFTTQ7YhIpALhUyLWFqhQ35PKs7YZbgOolF46v/sYBSAzdwsYzw5T5YI+Zkw1E6gV/Trh8oWe1UEVXVxDRj/xd+cjzvqWrno4vYR3Le3eL/qR9Dk5pQt3396cCSgs5rjTVcGwRlZGFkRC66nkvNx7pz2CUKN4sCMgmINpG0Gub11KFCpuq2GZS77h2K7z3g6c/BTRlEIRgJehV57HMsabkOcCt7ObCaKYkWv5xDlff4l0xsGwcmXodYz4bujJDrTSzu37gTHGJtm0NOgMCSlhnDNGl2Ojb2wfqfxqjupxsirz6nCgWgd9wtzp193Bs9zX3NCEDWMs9OUGzJEzpYqH77h44a/EQ9EBehWuB0LfIgCgHXmKAx7jXCXIDGqx1lD0Hkwz/n8RoMGLvz+5Bri9NfbbR4c4HpYwEmE/fuqTJD7J8lJ9HuaU8VRGKG1lAM+uejAsewPCNQgL3wHm1fibYvL+M6gMjp/2QkmLc4PU2jcuiSTsgjPzGh9Iar27J/hSmA5x60CIPGuuAV9BxycZb8sgVsSUeweOXD6cQNXN2HE7iA11EQVFTJZjRO/M/qAUkj2sc4GPMSv4UMNAWAlzOhkONw0jwRfNFvDRYB0aJ5eq97JI8L9OeCqN4Oc2bpokkHjK6hrKI2TxHPYrvfCKnsDBZIjf0gIeD+WkTfE9/+lZWmevp/M1ZR+OXl1EWbcYCGdMogRonY8TOs8MavY3eqvWCRIi+arafDEBaVKGZRGuIOdnVieFzDoIwoyzoT1KaSy2dyBEw66LziTH2SKprL7eFesz0qD+dgpDA36mGk0vVwa9+7cSKspOUUTP8ai3ph+3p/QL4SbkWNRCYCzKOET3JGJLT6qgaorvhuyk0S4JVSyasFRRM46asfbbjWCuV3hC8lOhyAm8r8sqZIWffprdwZ6ca5LkKcfgdLsrn0S0dFlM32JA3sDiEyx6k5hFk6khlFqyDPBGqQD7MDKLi0nJP2QX+KLhs2G0rrE0Rij09Xvurfcp004/SY/mx3RF6X4zXlqjJMfkMe4p6tbAjSBjAYEBMvHOyXGi3QrVgrjVvsd3wu9FzoUt+u/rwG96INcZhX9YHAd6/qAjTE5M3U2twIe5Cqze2JrccDkTNSFiZ2Rx2aLiU2s0U2vX14gdVNeGaJ8zwyO5xICLApBLfbHB0O3hq/eDqOpszd/bPchyyxlsmGqYVBm9NR6VE8JtUb84vQG19mMKM3u9gmCiL5jwR7c34+VdRSKIfK4mQVB4JCGYRslldhdhfrILvcUvejgRNLibN1e6LmdsbmT0fUYwakhuBHS4C3g2mzWGuTulK8WrvDjzIBtKt0dYCF5ZrrxbUoHe/4CINsgIpsbBjKZsdAm8EL9mQXjlW0F+8h7wUKfuvXfuW7/LZIxlR74lM3tRzgFxtBPjxfFC1NGQZI+LOqpNg3WGI9BAxBYiAk0A1USkXKEM2iG7lsMo9wCIHxI/r23muyjvA56WLxdMzr+c/5yn8SntLjiOv1MKU3z0gc/jrhsfeBAo81VtWp/zxfpw31nn3go7tjgisHb89oZ53Rotmykgzq3BndppKOwBbF3v8cEJrU0/tcKk8OsYh7EYPUNqRY19zz9Rf+gaKp4oVDicrUc04iK8F2Hu4+QO59Uztkf/0umDLfpvdFwJpM4mfeprdyGhX0o0UXolSc6OwZaiYb52/r2g/wAL+fpEcKkB3td5IDCqJe6lccFPDIN5jqXezt9wrQIExZbvdmRWHnieIlbvAv4D+1PvG1ehqZVTluKMCXRrRL8Xxq2R1A4DjTTLGcwwIlPa3GSVNjjuraw7tlbToZah/7FjvAhUQyjDu",
		"stD51eNLjrX6PQjPPAlKsJVWyplFdc0RhQ2gLYMc6L/P1g9M+PzNQuCR4jx049QvNUuETGSfbz6XgEi8oSOKdDdZrTgJgCW1j8xjeivM3WsOGbupwCvNVlbyX5W273fK1jFXQo+nnnpZ/GuGc9Ik50I/pllOKytLO8gV9IovjefaaC5PQifE8F0JBzMR2DClPyZYSnxk6uPhO86/YbP1EXn8JzSe2hdHXt48+9rO02EhzFGm3FjE9GNjubLLtGH6CTvLDOSiTixVV9ClZ0gbUFH+FKMrMgW5K+8CS54Pu9tu96K65rKdU0zTLpTm/Oh6316XLZEVGJnh9OqenyWWDcy8RIzcneonlx+PunB0OPHvgvQhZ2TJjN+JjqfuX9a1rfcftFlHI5CzVbxiMTNxbgXgte72mgnDMOJGDdj7Ji5Y7+qiy0CFrvZ9LQ9hVA1Rwa4By8dXPw/inUbG5GzCS08VsYM0EPHOIee4VfycQHtI9RoDt3SCGEaVn+7muxMwAXZDarkrHZp7EdvjXXv7MjJ4okUg1UPXKowETdnZpOFqtxT7zNKUYRtIMsDqCQ3ItU3V40128pjARFzsUjlhK43GX62LxR+eUCudvZzcad3rjftcZ968hmNoDKlsxJWY5ObRTubshp5Vf+DpY6+Ju6I6f3DA1dVVzx1ZNERSjVlD2+GwJIOqTDf49mvER/NnkulpuIjZNIIrjIdXbYxQ12Zz6tXrwv/OrzOR9EsbktXkqA0QoiaT6C5MhZBCy1njUTjDS76y+th0QgaXJju1yV7WF+evlHZRR5scWlPnvoIoBy1420vngdDwPDKmXg0O1JL/IhgomgeIJo+c/kes5q89LtKjMCYTn6QAbFaoEwgNhDPYyG/Wov4tuBVrMa0N5m/FnT+0UQ3z6zV7gqboUdpA9h8HDdlWEfV0y7rN6o8nD22F0jcoXyA7j/xxKK2AsBGJZ2QXkiYyZktldPinHQAq9nOzby0KLdvaU2u2rcb+nBQnRlAJBCaNJOQEx/lLwrkXs3To4ORLZG1e4hLj/r1zFdzidhbhmH4Gp6mV45zYeHQ0NFk6sRZniyzHzhN1nvLOAAaq+VnoW6s1jl2xUZnSuaneLKnSDIqH/mjWNfU/Pew4qScY/xGcQ3mxMoOA4B7oaq0TrbVqvTfzf+fmLn+TiQAvre9UjUgV3Je8/3K/6OgUPBbHrFBqi5bTS68PRP2+LsgR5n0VVmMvHgHc3+9pmqZURQotKvHv8KKRb8fc4mn9f3PEw+YMP09q6ytwZIZKM45eXgyFpKUTKZ3HlsqJ3x/Kp5pSLL40qpwmMwdWJ2QRCymyaDlNZHHX2ATCTFNOcLDn4dXhYz4gXMgAe0zzHnkjkfqsu5cMBH2uVs5ZkieWlEU/ZmaXJ95oUs7FYQ87a0tu9vZZi79s7i/v0gzzQkKsB5j5zr3W5iaWL1dbismo2zkss3Kaaj3N/x3WCNjhS0nO/NuXj4Ml48voPEnQtkkVwWMS84sMN4wXgOxbYpmNq0uV67YK/eLOKgGkLnKmIqNdVYphojImJaMxrmuwlM3fyya+osKIhQlWCmR78RzzRCD5b1Z0hLI7MBDh01LFVF8DgZjrqmloBwQ+wMlAB/rS9pTHusoZMQTfIfIuBQok4zzNRw1DjNPiwhP/xmGt7UBC0L9MqIChPd6XKdftMvk4TyA3DVbxNqSaqG277wo8mu/IxZz+8fSHVcvaiaBmHPdR6kcn2+tCAER7INckbWGbhQ+12Be3/kabVpK7Td9DcZ5TzCQUBDG+BDNywCUBwycntmurmurYMrRH2+rYpXhy0ongveIAV2fEmJR8S4aBAgUYMhkQLZPCd9jBW98A3+S4Epv0vL5yd2EbxmxMtNRTLJv30SbF0Rhp199tT5w96RlIPi71V1QsfZ2M/Bq9+ucaTG7eMBIsJBCq0YGRoNEMhVtDyTAovmQqaAT/3RpjB85yfdhztyfm1M8k",
		"AOhS0PtcAeKUzG0MiGkdT2SCGWAXc4lRo1/Fu5+JQaAN/hs4tQdmjXrGsy2VF0U3WxQcqcfG0AxdI+k9k06huIfqUoJcTccBAo4w1kPT2BNTRtJZSgOE7vvoUZROX2zZPVs3ypHUDZ3uBzE/ybsem/Vu2Fza9TdVPOnDz8kDkHYb90xf7fAFyIoq5jbGQoMQntFnh5Xiwvx1prK/R2X5xOo5pjBXZHpbbfl3YXWNwqb/35ibvG10wRKKGw5vaL8Ed6cusxlLtJPLS68L2aZX3i/0uWMf3OExBtj92XgM+Ltmf9VzpBtznCUQ6w98Qhq3k0yu3w/qKs4ynAm/sQpsaW34V100ry4xFBuyOENvnl4lltwHhkLiTMA25QoQYE/cS83CdAAeYUKpo8P2A2jZgTJhlSlmH4kas177IUu/3gxSW9LjN0OzUwDkl7dL/6pr/5tycjvrAJwPRRMZC8MFLgX6VubyeRqAouqBdlJ2QIHWSEI1TJw4fTkPgzDsHfT0FJaSHVb8U8cvT7lRZuupxqPFLCemYKF55egImiQYixqOYbJ1F1q2BCw0vj9MW8weRNWtLG4ECeCsTpaXbbEu7Qb9fcf6I7IM+XpMjaKWM+vbZxT6xFu2HTzqcMbT4GYrjKO8WRUMr8u7UjVjHg0YoPM2kfcYCfGV3DBb4eLnGKe4QXMbRUyhBnjdfmqnfCcCqllRes21ZC1gggBzcu15IW/BQ2u139PEDdVt0obbqExcEdK7yFhBy12/nczEOdzYTrDeI9xoncUMB9IX/GKoJGowgo2m0HGjPr9D1YPSg1RaV30zZgx2IphSHZjtAtGltguivuKZzEHawr4YnPfigBTQBe/OSLsaVAyTBkrIhLcCq1o4WZgv303UaVueCnQf7qR7FKBw8MRIKs87iLL6a/hs7TFw0g6ovwNskZqzuOSXDPl77iOP4+jBkEOynq9sjiNOyegVb4A16vcSGFpEb4+VMVJ5zg7fFkpDINeHPeY35xpLMpZWoPNwqFqUKhDYR/M91avf6kSkSNegOPg7NRfndoApMVhOe46ODwzT9aa9Y6HyT/Cork2B3BfYZl+rbxlgccDUUdsbKdsVighQOHz/xSYKQXRphrH8UWuNMKQiJ5PuBwHI2NHXS7epqPyo1lB1Y2opTnW78djq0lZtU02H6K8WIotsJYjSSK8oqzdN71iCB7o85Fm+bJqZsx8CWOyIuA1tD2wV930mVMTz9M4/QyaQrdOt1cC5AphwQLLcdz6AymGTR4w/UUtVDRv3Nh5ZaoU7fEsnTFLJcBhbqLekLvqtDXN6LrWNSJvw3g51PHs0i6V69I3vJDRNyI5ycIb4YMGkk2caXTbdkS2kQSho9zI8y5KYcop+ZsJdMttriHvDnxIg6sfTHwSA9LoY4vXOPYiBCLE1jQqv/06W2DWv0VZQaGJJJ4yq7tWnkDAYjy11cUixvNW6vPp6SAumJJk4xSUTB0KVdmhWwbH8y7MfAQ7KRR3QJeom00V11lPjCg9wFrUoaCepRR8MjajCRpgQ3sIqpTRfwgdGRlWXRNgtpXmLc6sJcdey7a8lQYmeEn+HtNc5c/24PqwtVn2d/0K6bJW8rdWd3aKeYP7adDGAGgdG8SZR3TblYHpx9Ld7wJspBa7dLrddNEiEzyG1mmPkbcbm/fvlU0G7gh0P3JOQ+mZarqo4NZmL8VqAr3Xhf1YjkJ/wvci429OmqWiMrvr7rJuyMy38U92aSxkZUvXgTnJKyUGPaRz5TDRkbQvx69b1f9Phr+dCjB4lt1WDs1vKFEBsHm8J1472ASL07y9lHykRAqLU4YvYuRlWzXZVA6WS9blYUBfZFPGD4fQnzQpEgutVyfZscCgUHGwohwu18XvBEt4hB1ItvxW2eWFHkvOXoM2WoSoXsLvHtfTClRkKe3vYhjSV9aITMfi0Eaw3OSjYrN1zn8/9YY1BbyZ+XNMQVZZYD4pNaj9a5hVe",
		"4Gxai24keaYvLKbNmvrVrhoK64ik96Kbf0Dz7Eo7Wek4TDvJF3T3gvU90uW3JnR6v8bRR2TFgb7oLxd7Wr9hhxG21BUAH6TjwyyRQO6Li8442laaU0/XhoSx/ZcbOHo30a7o1V4bKBuzS+a8K+sumpBOikoLxMm9rApztEdKlH3ZQjAaJGW2MD5pH5sl+QVgqdNOk/fVDoS/ggww0CxP1SS/n/B/i0bHYiPAYmoOADOzPjdZyTmbvsELoyulz5DD4YEWVZCYzz3ceL5rMit262Xe/9C+mybL2tVL8rgoaDheXj8tn4Y6tIOXmYjuFijRyKNgDDkQkaCaxGf/E1XJOt0NQhXZBh9wnKMbI4WkYhyLnLQkKRaWtP7yyCfy2CttHSvmN5rPwXXv1F7uf6JKEiBRogntsN+Nwhe9wCJ7u50KLCUae/TRv9Us4DqJvS+FT9Utp1SZG1a7SvXmGAiNhVP7w0oWE0wH6ohrIjR2Gqrx9tiCOW1Q2Bdt+HCExNx26FlHfE5wbc2qbs5MyJaChRhrdU1c0cPkWd+wz78Iv9AaHWj+hja02O7m78TX58NzfmitjEch0FvXd4qfHFq23ohSXl7ohSOQNuB1Jhtr7bBsOAU1Nslt16qnCdz5YiMmKu/Cg1C4vHo4nbAriJc5JacvC8kHso7UhkJVZtlypV4EFwAlDu6vvvp2iOwcXAup6duMZHCJSfSt33G6xqNjJqiMcmK8TrUrHIV/meHBuW0m4oHztr6Y0qmGMwlSYq6opo0K+mYdAlTJwJIHMNeZVPy3lrd/m6LfPpCVquuTMd1/mA6OESmdnPMBVwYVLiKL1EbkZ4d+4oPZ5bjcg4bkpn5mPXIYu18SiTmZkwMqNPCxFRMGHE7unfsBqx7VZZ1QmmImL3Mzr7MN9WNnS1oB+jin5xPBI9myqrbjdI89+preWWwubJSHxUgue4QVWW8AjYd0vetUbWfhNykScUn/kAlkyOM5Tj2pSB5b0Yg8N+nl7Laz+nCU+YLWOigAZGhN8jUJJ1oLVVBJm+Cz2crKVeLFzpkRjuOZbA2dq4QS8Yb389IVg/1q7rAzzTtIq+bOxTm8pdWz/Pu/Wtu1gdfAkL8ImLNW/D6KSqT3kVj/9FzgsXOOqOKKkjx9yGTyPdOelestFZqDNIdZIcmtKljaiRJgs4omidADMf6UivlK4Q0tDrntn3USO/kMYau2DOTuwqQObofB1sPS97CEs7dkoGgLUZdgIpyLLIZOnskSGh/9Z/567hYwcTiik/Bx+9LRw9LYQ+cZhdzo3h26XBqPkSy3M8E8x+h8pDpVR6EYeBvgHJMB0v6vUwoEqNG0WVubiqugPZjXGwJa9QGWGuaFGU4qDB6xjwrJirqjTvfdoZK15Z0JnGvSjZEEDYo2NwBsH3D2YIHyKOw+Qc5iWApi22GBWepSYiSo3GUysF40DJ0R1DomnzdqmJTpesjtKektaLESYmqTtZk0glniOP8fmQEYhdiTSJSZ24xeyf0Bn4lPld78irtWz1sRGXgMfG2ScZ8NogiGQMxocqM40aDQX3RpsOMH9CyAC02jiu3/T1gvyohe2IYvFMu9Vzn0JV8/mvl9T1cbsU5xvJNVWqGGJWXew1Urm8ZaSMsIDZuG+UacUrifsM0XZ6bQLgnsnOByRJTajZ3qTOUcM6g+9nCmboKu9rEh1UIQ7gckgWZ+eTRaJjKBuexAhY/WArtmWdGQ7Z7MvPdAB085LHu1jj1aOzrg5sERebx5m7zw50EDm1Qeqa3hd6w6JQgf9/GOpY/Ehd1ilve4wvFYo/+XNBgfqhBIAIZBBXZl17CH/4xRubdgSxtH72JNwTpDYmuMv86gsgvmPsTIdBhGZwaGkyax7PY1/By1dy+SfYhieXsoih/awpBTy4c5yPrt9NKoyz19GFCy6HW3n20ohdfYQ4smhTkgoamp6aauRDrq37Yoeb91wyUtaYeBAGy5+DBrBH+h",
		"5HlnTio8k/2y6NvK78ea3nC/+YdfUoVwwsQygFqJpX93PXKpiNn2iR1l5Qo9X9b7dpd999N65Xp5I0kmwkhOMcTeYHgN94GUbz4ZGfOjHcezzaxS8Oi3K2cFtLmFcYwFXRu2DxQ0KzMwqP+qG5iixn5j5X2+hjFyEnVGfhLmf34stZ/YXkmsS36k49hARElp78RJWvnr7FHxPOb2fEr/SeE1TWFFSNEkYSb/ZN82YnvmZswq6F5mEVErSs4N+6ibstPF+K4lCABJyT4j6A615UXOOE+lWmYmwilYiFzW08jU5Yb7u4uuAB8pFnXTigXlx2j8m0GrOtgM28VUMwivv7O6ocRu5Z+N8VTe6jquBEyE2MkqDazSyWppI6GNKFuSru2pnud5iz2/w6QTMibgnO6P96/s+ghf+YJekNJbBoPJNDx2l31LX9tIcVPljpzQbl4xFhfs1oZI0lrkqkjqdUFVAFTExO9Ga+vNbKBCgt2AH32G+cy/2Vgk/WQh3EToYPKfBLrO6HaTR5Xsh0Hq75c81b/HXpbQ4vjHBUtBChc7vsDSJ6DNY5f2htJTOQivykBBhFhnbVkw2GeghxQFVOqcLkE0OjZQ32g7T7MCiGKWjVgfwuJttsYpgvnyVYClZiKHXmSjFYOfmCVVJ/Agu0pSDJKLObn/rTHaHOmw2wL3Pm8dDkrsB4VbvJuP8IzcQHUTUBVhaU0i+8y0kDKLnl5F5oQDQ4oUQtGq1sQkZsqBUL22jhNhGV919wghxKwHoGTuR6p+vvUHH6PO/ao2fWAufwsEPH8ZQxWlSg7Vg0lM8VufzoddbSczfuHNyvoU3aEL5FLGH+NKPXY9su5KxQlih5G5BuQfc09dlPWK23fdIc+3cxksLpklRc9czUUaZ95iozoDHun/+Kn0R5eOlkiLteO7nmcCwo0K3eKHMAXDQ7pU8iqyBAv3InGBsJXTKzNJPCV9GLiZCwSop3Y9lghag8GC3iSOL5ZthkczTRLwPAjEwaky7dDAyczFd2888J12piwVR2ki1r3DxY0d4MduKBhML4reV0rvnLl7pOb6yk3S2P5TWcWioNLr8ZVx/IkPsIAvn8nywG1VlDCMTdwnQ4J//2wgUvkbLwzgU/vT8T3E6Ek2AifLo1/DKZfVLRJDOD7T0ady3/JtK5yj5QdgdoFfUhPc0Paobc4o4Yu0+giMD25gZcRdRuXo4vkDPw/ucpY8oYETnR2VS4RrKl6/L1CKvbzUoH4/RjdeI8cK89EUYN2DbC97J+FqfnC0EI87fWfGVk0vtsZ9og8+1Nbab184fq74J8UOsRQkKT9Ns2noxfMAdLsXLFgXZ+/BtsfQa0e/yjBY4Y18szD18y5mMpwcd1CIT0CWuNTfqLdSzOcEXd+VICguCCexnunLD2GH3xEzfHe/cfohNRFXV+Af8GWNpQ81tTRRUh8qrW6GIZIQn/2AB8jMtqMuX6Jk6cp1nYE4YJ17hDIjwQrAhogjGb+wewguVY+22cbGvmHrByz+sA1xaoOyn0iw6z5s/vrv857eyM9dFV3lpGme7GpYmaE+aJ0be9QkHoj0fSSAYAlFqBnpynEGRb98SgFxnvuP1k5/sMYoIaSWqCxP+t6bRIlQzG4d00+sYer4SFvtti7DY2s0UeCNC2qFUF6OCgZrRP48Qf199Ga+OlztIENJz8m/0b3kiRnKkIfWC3y9i7RMg1puEMS93uFZ7bQzdTc3HDwLCE9tvL79LgOO2phqW2A/8Pqj3ly52gL3egDx+n2HFQraZXNDB+BEM3m1HvibDJNBLvwLrUUOr0YkdzMXAayga6t+tRGhw92uzh8Eo1SFJ/HRfQepvAXXYc48iR99izaJeZGaBHjjTFls+c6LpQyf1zDtGMXvzcJO3sh2VJ6MtYnch1AL0ZpiQS0CVF3Pj/i8JFPUO14C8IDRxpguXhviUbGvEncp0DVzcz0+1+oQw73OPk6AeZLpH/S4",
		"XxS3dULuoFaZIbpHZBsE6tXc0d7g1BEnc5nkxAbHO1O7J5jqNcQTzY0qY2094oD8rQOLRvvb2UlyyA44lMf6YmsP8QQfbLxNlrZZOlq7+FLuBI9bZO49EqB5r73hmzUIdiBfkXenCcQZ0wnb1FMqHpOWz8ugEV8t56c9eERvcDqpwYUxVP9ohJaGHQA4doRH/LnGsCdzcKK2FJlpaQwz7MPWszkxj1mmcV/5fVnkeqK2YBrWsdOTg41qqbWW2VyhJ0ej8q79X/zvHI0DCmrCplEAceDe6ewcvlzghZ70uaMlIt9gHBPAj7cu4wLiURjoAJ6rZiFKfu12g7aFit7QqIcJ7NPQKOAjMamCgZlbby1/ixTleog3dKNFbDa0qA5ndJ/2OZQ6W/dBeHRgZjM+MoNGteQ/ras0gxl/shxtMNgnFvAIPnv3eR5HQmwHSSJ9F+dSEKUfuijMggwppcWhX/v38y3c1GiWdVwZC0H7cvLd8uGT8jrEcqGNiCKWn/N0slKt0MCZSYzdckQZbIa0AN2/HzwO+3MyGeFZB6TxMrOQpRin4Rj8RfAQWHGjspz8NQ/IBKfnoU7VShs6elM6N0sIHbMgkCvECooZIPyABWdDJqBYFUDY1S1uppf7TXTCewoX8tAo1vwyZ7trgPvfUgedGajnUoGtf7ctwIK5OWRw7zmp9WRVeXAEGBupN2VjpqB93GjtyIR0RNgD09B9iVw1yohyFP+ZJLvaq6WQe1DbT0PRDNwuan2AYQIvNcQg8Jl1i6HeP/JD7pzoER3MCsSlSxbE8v+b9DviwpcBPOZzmWBrC4p9Oc4Q22l9KC1DyGCdDwaJnQO2upZ3eOdb55MC66yylq3aiUuzJ0NcoLvojEvWm03TprVqaewMlO8TjkQuiufW8DYznGOWJucNGFjqOYdx95cYi5l6p3IiH69TPHjzptwqcAlai7moe9c8t/JdfLQlqak/KQqu8DlD8oD16MRXneDyP2TubnsuiMyFKlddYWdYkAOK0bc3GCiPKpMP+7RuDEbXSHVbyCOKhpvM6/WneBMhoU+QXI2y7fz4GTWUnO4cOncEigEt5BW8YxXDZ5stgyE/QBYYiaLbXT3yg3jQJX9ZLGW9d8VPNBF/hWZMm5BDbTKv2z6NLeuknD7TN04pIugSUTICchF7vp1Bo0ZVPXP38vfafFRTrpvaxMJuU/tCUAZGlIbedg3tAUU864KWLxEgRGVOuwan22WemRCw+DwnLL/y9sizi7OJOktzPFL8uJ67A0+aICzVEpAhhzvOTqI5KsO/ifrDmQGKeEM6wIje3Dx5VbvYQ9u8iLP5jLNNNCl9SIWsnFUPVpMxfEwjvURcrnf40v8Uwxgesg21vT/Y7uXz9fvrBlUvxAyTcZJ+QCo01Ud6tYNbOnNnT8zn9U2ytMtuNxwj4TLSqUjehcFksQBZbFvY0UX6tbACIjXmuOsVALNNj/nlcDVt0gIEwtFVysiM81+hh6St1IYLt/KxQl8xzTxfqlXUCx7xtSZXJxOCRu+CGak49oOW8pI2OzqAuOvrAzM98u2w3hq9lfqI51Vee4eOLdRmXPOK/vtB9UOw5VXq0tdhSd+ecvyfHuu6El0d2uOqf8YW0n36/EmUij5aDlPoOCFhqJ0OFyl3y9R9UFPX/J5ifKeVpwAMKpl/+9EOFOqIrxpREsbEpcnbXixIAyU0+fEqcTBgfmbOajK8Dl5or8u8M3Aau8LUpQpiANWd7f4SAqXCats7GhNa1qHNEK/72JnOxQXFd9poBCMH5a7x+7P15sY+MDBn74QNPB+KczTiY5ktO2M8oXkZeB/H13Mz+9hJGNekcoYnjqBirSLYCd7+RXKOHW76l6V3l6OCD9Bh31v4Y8grOoNkl/HvOjLUHCFMej/H1ViMWUVzRGdKTbO4fsM1lH8WbKaoSiLwMlePqOeOdDJFef2xOJ18SZfBjWlnF4CFVhoyu5pX67ahD+BO",
		"kQQ1ULOrByNkQsSqbEGfkduX5AS+3lDRd4V/NZBowlwLZnEmAGvWJcxPMhD2FzacarxSSo9p23RiCd6s6upifro7TsNLxS5dmx2LFBpvbolJjEq8/Jp2O/Jbzrg9ahqsyXKrWl7jHENsrRDl/XRg02mdtCPbkF5rSc63Yrqg//EQ2TYK94dNQmAawKVD6N8Es1rYAgVFkenuhauVSSlobFu1n0j7xg4dpgt7Niwi4BU1PkJMWGhtSXJEBHBc0q5s65dZd0MuSEagqD8YhsY/LqjkvBoFa7ZQjgcqifsaVWnYWyMVh88XbFRV7yot0joCiVBdnhn9NBOTM6x8D9qIm+M/ZYfpIzVskM/bOeewDo0Mt8p8dZpzMGr9LeL0UIzd29jvgmaeL696m1bPewAcQRkjulioQkGP08SuCEROSdd3E3AO26oodi8TQb6yWENwfiRW5t2+/5mIT5Nc00z5MhCUDS7+5iWC/FZ5RHzcr51He56QS1jF+Oice6nd1ivWz/1h5FceR7A3mLdL2DHU+kXrEFndLcHF8aQbZhB3td2pMCagjk0/PHJMmyJ0yPZhVffCnuTLBNEyvFxkfXL/1aElkwN6V+5EHZoz2IqPisgW2FaoDYaS37uK/CQireWcU3SDhlm7o4lJZ9sRUcOjmyjqpLYcvqW7LeUJPdTnfgQR5HYHQBxf7+QDlAj42j66FIprQlt9OiZdKqodt9Xy2z6aprcmt42DXKZoxwil1qx+x5ADnTikqYsYUlrdaBKkLYg5stiCCE2A0VFjSHhC59GLyGjsUJVLB3rRHcL8XIGMB8RESOWq2ZHw2Bq22CjrbxDReN/iYMipYSBMj84vWj8OJ2KsnCWeqlpAp7XBDoUqHSPds8UvpITZASF8lAlD2io9o6FWyeWSRTSy0GXP7YHs3Ear5Jv1+3/8ge3hwPgbFlfc0Cs0H486Sx9gW7F66Tp12Yii/wHBERRGiK2xByqhlEeLpZRLwdOGHolQb1xOw55NhuF+g4GHE6BQ4YCMEJYjrprG5ssymuQCkNfqRDzZnZbPkbDO58btuN5CAW3prA5urQDzHsOwQrmsMhS1oYZwRQAKWpgZJXXauxM6S3I+/LXxG0c9YDRRQc1+JH1YUpgjHxAni0hJDhvXXQKS/VZ7vOICAV+rkfn8vcAou2lOvHoliIdQf2aSVsFhFogJTn05ilsMbmD9SwX086gljBpe1ll0iqe8aqxGwt9irgu5d934TctiDEIn0YrI8WTvvLbDnPLFSbbdlkRQtRrQtNy5yGFXYU4Fk2bak6I4jeP4inc8PBOJ6xfhsxDeHyJwyORXGDFKks/r3QhFqePxEec23IkEzXm8y96Ev1t1CPnCDxI4RZhTuRF+0yJoUgf4ebHDIzct+pEaXgUwJ9LM2Q97NmJt3n0trVOs3E/VE9JrY21xJam00m63dhI6d6oIpWuByXAm/eul0rPrI7BdHBn0QPoeNW44rq26KbKAgiMncEbp7kICxuDjf2Rbz6nI5ZteCZF6KbyDoFD0hEPnJbo1qSu4BNT/x6EvnLSB+/ClGIzacNlWMora0sCnnIRYYIFFUb4IqmUtFL/2gNW4YueMc9Xua5gFItIKvZp0y/hvd93ecYB7CZiRzbKEhK85RQhAt0w0HsDXq4GCzQd8mEwhP0oB0ifNfWRU2a5AjbZu5FhqiMPsgMVCWqw13dPQua5V//smLYS9fsHnmcuYQZFoDrsoIpOd6FC+3JiA2I70C9nwPilM2fB+7xTF8sguiNJh3eZVvgxl9KAnRPWTTkf2zHylYPPucRnmoPkM+/A3E9bafVmJcrjXRiKCakaaj5KYD/mosY4NaaY5tt4K003cS+Gcb4QRsuVeqOzV8B9ZXVL+SwHx5rfrV4tDzRV1AoE89U0hawDefgRg0At/6tXwuwltm0tuWoxY8P0p7sh8g5W1zBXbdJme3KTmbSQXwuQW42kZDYL+LehrfGa0"]
	while not sig:
		vec = {"vec": random.choice(veclist)}
		req = requests.post('https://www.vavoo.tv/api/box/ping2', data=vec).json()
		if req.get('signed'):
			sig = req['signed']
		elif req.get('data', {}).get('signed'):
			sig = req['data']['signed']
	set_cache('signfile', sig)
	return sig

def yesno(heading, line1, line2="", line3="", nolabel="", yeslabel=""):
	if six.PY3:return xbmcgui.Dialog().yesno(heading, line1+"\n"+line2+"\n"+line3, nolabel, yeslabel)
	else:return xbmcgui.Dialog().yesno(heading, line1,line2,line3, nolabel, yeslabel)
	
def ok(heading, line1, line2="", line3=""):
	if six.PY3:return xbmcgui.Dialog().ok(heading, line1+"\n"+line2+"\n"+line3)
	else:return xbmcgui.Dialog().ok(heading, line1,line2,line3)

def get_data(params):
	from resources.lib.handler.requestHandler import cRequestHandler
	query = params.get("query")
	p=int(params.get("p",1))
	if query:
		_id = params.get("id").replace("series","tv")
		url = "%ssearch/%s?api_key=%s&language=de&query=%s&page=%s"%(tmdburl,_id, api_key,quote(query), p)
		oRequest = cRequestHandler(url)
		oRequest.cacheTime = 60 * 60 * 24 * 14
		return json.loads(oRequest.request())
	today=datetime.now().date()
	t, i=params.get("id").replace("series","tv").split(".")
	s=int(params.get("s", 0))
	e=int(params.get("e", 0))
	urlparams = {"api_key": api_key,"language": "de", "region": "DE"}
	if i not in ["now_playing","top_rated","popular","on_tv","trending_day","trending_week"]:
		urlparams.update({"include_video_language": "en,null,de", "include_image_language": "en,null,de"})
	release="release_date.lte" if t=="movie" else "air_date.lte"
	count = 300 if t == "movie" else 150
	if i =="trending_day":
		urlparams.update({"page":p})
		url = "%strending/%s/day" %(tmdburl, t)
	elif i == "trending_week":
		urlparams.update({"page":p})
		url = "%strending/%s/week" %(tmdburl, t)
	elif i =="now_playing":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc","include_video":"true","release_date.gte":today-timedelta(days=41),"release_date.lte":today+timedelta(days=1),"with_release_type":3,"page":p})
	elif i == "popular":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc",release:today,"page":p})
	elif i == "top_rated":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"vote_average.desc",release:today,"vote_count.gte":count,"page":p})
	elif i == "on_tv":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc","air_date.gte":today,"air_date.lte":today+timedelta(days=64),"page":p})
	elif t == "movie":
		url = "%smovie/%s" % (tmdburl, i)
		urlparams.update({"append_to_response":"credits,external_ids,videos,keywords,release_dates,alternative_titles"})
	elif (e != 0) or (s != 0):
		url = "%stv/%s/season/%s" % (tmdburl, i, s)
		urlparams.update({"append_to_response":"credits,external_ids,videos,alternative_titles"})
	else:
		url = "%stv/%s" % (tmdburl, i)
		urlparams.update({"append_to_response":"credits,external_ids,videos,keywords,content_ratings,alternative_titles"})
	url = "%s?%s" % (url, urlencode(urlparams))
	oRequest = cRequestHandler(url)
	oRequest.cacheTime = 60 * 60 * 24 * 14
	return json.loads(oRequest.request())

def getIcon(name, original=False):
	if not name: return "DefaultFolder.png"
	if "/" in name: return tmdbimg % ("original" if original else "w342", name)
	icon = translate_path(addonPath, "resources", "art", "%s.png"%name)
	if os.path.exists(icon): return icon
	return "DefaultFolder.png"

def getPluginUrl(params):
	return sys.argv[0] + "?" + urlencode(params)
	
def genrelist(params):
	url ="%sgenre/%s/list?api_key=%s&language=de"%(tmdburl, "movie" if "movie" in params["id"] else "tv", api_key)
	oRequest = cRequestHandler(url)
	oRequest.cacheTime = 60 * 60 * 24 * 14
	return json.loads(oRequest.request())["genres"]

def platform(): # Aufgeführte Plattformen zum Anzeigen der Systemplattform
	if xbmc.getCondVisibility('system.platform.android'):
		return 'Android'
	elif xbmc.getCondVisibility('system.platform.linux'):
		return 'Linux'
	elif xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
		return 'Linux/RPi'
	elif xbmc.getCondVisibility('system.platform.windows'):
		return 'Windows'
	elif xbmc.getCondVisibility('system.platform.uwp'):
		return 'Windows UWP'	  
	elif xbmc.getCondVisibility('system.platform.osx'):
		return 'OSX'
	elif xbmc.getCondVisibility('system.platform.atv2'):
		return 'ATV2'
	elif xbmc.getCondVisibility('system.platform.ios'):
		return 'iOS'
	elif xbmc.getCondVisibility('system.platform.darwin'):
		return 'iOS'
	elif xbmc.getCondVisibility('system.platform.xbox'):
		return 'XBOX'
	elif xbmc.getCondVisibility('System.HasAddon(service.coreelec.settings)'):
		return "CoreElec"
	elif xbmc.getCondVisibility('System.HasAddon(service.libreelec.settings)'):
		return "LibreElec"
	elif xbmc.getCondVisibility('System.HasAddon(service.osmc.settings)'):
		return "OSMC"		
		

def pluginInfo(): # Plugin Support Informationen
	pass

 
def textBox(heading, announce):
	class TextBox():

		def __init__(self, *args, **kwargs):
			self.WINDOW = 10147
			self.CONTROL_LABEL = 1
			self.CONTROL_TEXTBOX = 5
			xbmc.executebuiltin("ActivateWindow(%d)" % (self.WINDOW, ))
			self.win = xbmcgui.Window(self.WINDOW)
			xbmc.sleep(500)
			self.setControls()

		def setControls(self):
			self.win.getControl(self.CONTROL_LABEL).setLabel(heading)
			try:
				f = open(announce)
				text = f.read()
			except:
				text = announce
			self.win.getControl(self.CONTROL_TEXTBOX).setText(str(text))
			return

	TextBox()
	while xbmc.getCondVisibility('Window.IsVisible(10147)'):
		xbmc.sleep(500)
 
 
class cParser:
	@staticmethod
	def parseSingleResult(sHtmlContent, pattern):
		aMatches = None
		if sHtmlContent:
			aMatches = re.compile(pattern).findall(sHtmlContent)
			if len(aMatches) == 1:
				aMatches[0] = cParser.replaceSpecialCharacters(aMatches[0])
				return True, aMatches[0]
		return False, aMatches

	@staticmethod
	def replaceSpecialCharacters(s):
		for t in (('\\/', '/'), ('&amp;', '&'), ('\\u00c4', 'Ä'), ('\\u00e4', 'ä'),
			('\\u00d6', 'Ö'), ('\\u00f6', 'ö'), ('\\u00dc', 'Ü'), ('\\u00fc', 'ü'),
			('\\u00df', 'ß'), ('\\u2013', '-'), ('\\u00b2', '²'), ('\\u00b3', '³'),
			('\\u00e9', 'é'), ('\\u2018', '‘'), ('\\u201e', '„'), ('\\u201c', '“'),
			('\\u00c9', 'É'), ('\\u2026', '...'), ('\\u202fh', 'h'), ('\\u2019', '’'),
			('\\u0308', '̈'), ('\\u00e8', 'è'), ('#038;', ''), ('\\u00f8', 'ø'),
			('／', '/'), ('\\u00e1', 'á'), ('&#8211;', '-'), ('&#8220;', '“'), ('&#8222;', '„'),
			('&#8217;', '’'), ('&#8230;', '…'), ('&#039;', "'")):
			try:
				s = s.replace(*t)
			except:
				pass
		try:
			re.sub(u'é', 'é', s)
			re.sub(u'É', 'É', s)
			# kill all other unicode chars
			r = re.compile(r'[^\W\d_]', re.U)
			r.sub('', s)
		except:
			pass
		return s

	@staticmethod
	def parse(sHtmlContent, pattern, iMinFoundValue=1, ignoreCase=False):
		aMatches = None
		if sHtmlContent:
			sHtmlContent = cParser.replaceSpecialCharacters(sHtmlContent)
			if ignoreCase:
				aMatches = re.compile(pattern, re.DOTALL | re.I).findall(sHtmlContent)
			else:
				aMatches = re.compile(pattern, re.DOTALL).findall(sHtmlContent)
			if len(aMatches) >= iMinFoundValue:
				return True, aMatches
		return False, aMatches

	@staticmethod
	def replace(pattern, sReplaceString, sValue):
		return re.sub(pattern, sReplaceString, sValue)

	@staticmethod
	def search(sSearch, sValue):
		return re.search(sSearch, sValue, re.IGNORECASE)

	@staticmethod
	def escape(sValue):
		return re.escape(sValue)

	@staticmethod
	def getNumberFromString(sValue):
		pattern = '\\d+'
		aMatches = re.findall(pattern, sValue)
		if len(aMatches) > 0:
			return int(aMatches[0])
		return 0

	@staticmethod
	def urlparse(sUrl):
		return urlparse(sUrl.replace('www.', '')).netloc.title()

	@staticmethod
	def urlDecode(sUrl):
		return unquote(sUrl)

	@staticmethod
	def urlEncode(sUrl, safe=''):
		return quote(sUrl, safe)

	@staticmethod
	def unquotePlus(sUrl):
		return unquote_plus(sUrl)

	@staticmethod
	def quotePlus(sUrl):
		return quote_plus(sUrl)

	@staticmethod
	def B64decode(text):
		import base64
		b = base64.b64decode(text).decode('utf-8')
		return b


class logger:
	@staticmethod
	def info(sInfo):
		logger.__writeLog(sInfo, cLogLevel=xbmc.LOGINFO)

	@staticmethod
	def debug(sInfo):
		logger.__writeLog(sInfo, cLogLevel=xbmc.LOGDEBUG)

	@staticmethod
	def warning(sInfo):
		logger.__writeLog(sInfo, cLogLevel=xbmc.LOGWARNING)

	@staticmethod
	def error(sInfo):
		logger.__writeLog(sInfo, cLogLevel=xbmc.LOGERROR)

	@staticmethod
	def fatal(sInfo):
		logger.__writeLog(sInfo, cLogLevel=xbmc.LOGFATAL)

	@staticmethod
	def __writeLog(sLog, cLogLevel=xbmc.LOGDEBUG):
		from resources.lib.handler.ParameterHandler import ParameterHandler
		params = ParameterHandler()
		#if utils.get_setting("debug") == 'true':
		if True:
			cLogLevel=xbmc.LOGINFO
		try:
			if params.exist('site'):
				site = params.getValue('site')
				sLog = "[xStream Scraper] -> [%s]: %s" % (site, sLog)
			else:
				sLog = "[xStream Scraper] %s" % (sLog)
			if xbmc.getInfoLabel('System.BuildVersionCode') == '':
				
				if cLogLevel == 1:
					settings.logging.info(sLog)
				elif cLogLevel == 3:
					settings.logging.error(sLog)
				elif cLogLevel == 4:
					settings.logging.critical(sLog)
				else:
					settings.logging.debug(sLog)
			xbmc.log(sLog, cLogLevel)
		except Exception as e:
			if xbmc.getInfoLabel('System.BuildVersionCode') == '':
				print('Logging Failure: %s' % e)
			xbmc.log('Logging Failure: %s' % e, cLogLevel)
			pass

class cUtil:
	@staticmethod
	def removeHtmlTags(sValue, sReplace=''):
		p = re.compile(r'<.*?>')
		return p.sub(sReplace, sValue)

	@staticmethod
	def unescape(text):
		def fixup(m):
			text = m.group(0)
			if not text.endswith(';'): text += ';'
			if text[:2] == '&#':
				try:
					if text[:3] == '&#x':
						return unichr(int(text[3:-1], 16))
					else:
						return unichr(int(text[2:-1]))
				except ValueError:
					pass
			else:
				try:
					text = unichr(name2codepoint[text[1:-1]])
				except KeyError:
					pass
			return text

		if isinstance(text, str):
			try:
				text = text.decode('utf-8')
			except Exception:
				try:
					text = text.decode('utf-8', 'ignore')
				except Exception:
					pass
		return re.sub("&(\\w+;|#x?\\d+;?)", fixup, text.strip())

	@staticmethod
	def cleanse_text(text):
		if text is None: text = ''
		text = cUtil.removeHtmlTags(text)
		return text

	@staticmethod
	def evp_decode(cipher_text, passphrase, salt=None):
		if not salt:
			salt = cipher_text[8:16]
			cipher_text = cipher_text[16:]
		key, iv = cUtil.evpKDF(passphrase, salt)
		decrypter = pyaes.Decrypter(pyaes.AESModeOfOperationCBC(key, iv))
		plain_text = decrypter.feed(cipher_text)
		plain_text += decrypter.feed()
		return plain_text.decode("utf-8")

	@staticmethod
	def evpKDF(pwd, salt, key_size=32, iv_size=16):
		temp = b''
		fd = temp
		while len(fd) < key_size + iv_size:
			h = hashlib.md5()
			h.update(temp + pwd + salt)
			temp = h.digest()
			fd += temp
		key = fd[0:key_size]
		iv = fd[key_size:key_size + iv_size]
		return key, iv
