import logging

def init():
	logging.basicConfig(filename='/sdcard/test/logfile.log', filemode='w', encoding='utf-8', level=logging.DEBUG)
	global aDirectory
	global urlparams
	global collectMode
	aDirectory = []
	urlparams = {}
	collectMode = False