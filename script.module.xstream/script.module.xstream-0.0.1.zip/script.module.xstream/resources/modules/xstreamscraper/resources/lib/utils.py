# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, xbmcvfs, sys, os, time, json, hashlib, requests, io, six
from datetime import datetime,date,timedelta
from six.moves.urllib.parse import urlencode
from resources.lib.tools import logger
from resources.lib import common
PY2 = six.PY2
PY3 = six.PY3
addon = xbmcaddon.Addon()
addonInfo = addon.getAddonInfo
addonID = addonInfo('id')
addonName = addonInfo('name')
get_setting = addon.getSetting
set_setting = addon.setSetting
api_key="86dd18b04874d9c94afadde7993d94e3"
tmdburl = "https://api.themoviedb.org/3/"
tmdbimg = "https://image.tmdb.org/t/p/%s%s"
translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath

def py2dec(msg):
	if PY2:
		return msg.decode("utf-8")
	return msg

def translate_path(*args):
	return py2dec(os.path.join(*args))

addonPath = common.addonPath
profilePath = common.profilePath

#if not os.path.exists(profilePath):
	#os.makedirs(profilePath)

def handle():
	if len(sys.argv) > 1 and sys.argv[1].isdigit():
		handle = int(sys.argv[1])
	else:
		handle = -1
	return handle

def selectDialog(list, heading=None, multiselect = False):
	if heading == 'default' or heading is None:
		heading = xbmcaddon.Addon().getAddonInfo('name')
	if multiselect:
		return xbmcgui.Dialog().multiselect(str(heading), list)
	return xbmcgui.Dialog().select(str(heading), list)

home = xbmcgui.Window(10000)

def set_cache(key, value, timeout=300):
	data={"sigValidUntil": int(time.time()) +timeout,"value": value}
	home.setProperty(key, json.dumps(data))
	
def get_cache(key):
	keyfile = home.getProperty(key)
	if keyfile:
		r = json.loads(keyfile)
		if r.get('sigValidUntil', 0) > int(time.time()):
			return r.get('value')
		home.clearProperty(key)
	return

def getAuthSignature():
	vec = {"vec": "9frjpxPjxSNilxJPCJ0XGYs6scej3dW/h/VWlnKUiLSG8IP7mfyDU7NirOlld+VtCKGj03XjetfliDMhIev7wcARo+YTU8KPFuVQP9E2DVXzY2BFo1NhE6qEmPfNDnm74eyl/7iFJ0EETm6XbYyz8IKBkAqPN/Spp3PZ2ulKg3QBSDxcVN4R5zRn7OsgLJ2CNTuWkd/h451lDCp+TtTuvnAEhcQckdsydFhTZCK5IiWrrTIC/d4qDXEd+GtOP4hPdoIuCaNzYfX3lLCwFENC6RZoTBYLrcKVVgbqyQZ7DnLqfLqvf3z0FVUWx9H21liGFpByzdnoxyFkue3NzrFtkRL37xkx9ITucepSYKzUVEfyBh+/3mtzKY26VIRkJFkpf8KVcCRNrTRQn47Wuq4gC7sSwT7eHCAydKSACcUMMdpPSvbvfOmIqeBNA83osX8FPFYUMZsjvYNEE3arbFiGsQlggBKgg1V3oN+5ni3Vjc5InHg/xv476LHDFnNdAJx448ph3DoAiJjr2g4ZTNynfSxdzA68qSuJY8UjyzgDjG0RIMv2h7DlQNjkAXv4k1BrPpfOiOqH67yIarNmkPIwrIV+W9TTV/yRyE1LEgOr4DK8uW2AUtHOPA2gn6P5sgFyi68w55MZBPepddfYTQ+E1N6R/hWnMYPt/i0xSUeMPekX47iucfpFBEv9Uh9zdGiEB+0P3LVMP+q+pbBU4o1NkKyY1V8wH1Wilr0a+q87kEnQ1LWYMMBhaP9yFseGSbYwdeLsX9uR1uPaN+u4woO2g8sw9Y5ze5XMgOVpFCZaut02I5k0U4WPyN5adQjG8sAzxsI3KsV04DEVymj224iqg2Lzz53Xz9yEy+7/85ILQpJ6llCyqpHLFyHq/kJxYPhDUF755WaHJEaFRPxUqbparNX+mCE9Xzy7Q/KTgAPiRS41FHXXv+7XSPp4cy9jli0BVnYf13Xsp28OGs/D8Nl3NgEn3/eUcMN80JRdsOrV62fnBVMBNf36+LbISdvsFAFr0xyuPGmlIETcFyxJkrGZnhHAxwzsvZ+Uwf8lffBfZFPRrNv+tgeeLpatVcHLHZGeTgWWml6tIHwWUqv2TVJeMkAEL5PPS4Gtbscau5HM+FEjtGS+KClfX1CNKvgYJl7mLDEf5ZYQv5kHaoQ6RcPaR6vUNn02zpq5/X3EPIgUKF0r/0ctmoT84B2J1BKfCbctdFY9br7JSJ6DvUxyde68jB+Il6qNcQwTFj4cNErk4x719Y42NoAnnQYC2/qfL/gAhJl8TKMvBt3Bno+va8ve8E0z8yEuMLUqe8OXLce6nCa+L5LYK1aBdb60BYbMeWk1qmG6Nk9OnYLhzDyrd9iHDd7X95OM6X5wiMVZRn5ebw4askTTc50xmrg4eic2U1w1JpSEjdH/u/hXrWKSMWAxaj34uQnMuWxPZEXoVxzGyuUbroXRfkhzpqmqqqOcypjsWPdq5BOUGL/Riwjm6yMI0x9kbO8+VoQ6RYfjAbxNriZ1cQ+AW1fqEgnRWXmjt4Z1M0ygUBi8w71bDML1YG6UHeC2cJ2CCCxSrfycKQhpSdI1QIuwd2eyIpd4LgwrMiY3xNWreAF+qobNxvE7ypKTISNrz0iYIhU0aKNlcGwYd0FXIRfKVBzSBe4MRK2pGLDNO6ytoHxvJweZ8h1XG8RWc4aB5gTnB7Tjiqym4b64lRdj1DPHJnzD4aqRixpXhzYzWVDN2kONCR5i2quYbnVFN4sSfLiKeOwKX4JdmzpYixNZXjLkG14seS6KR0Wl8Itp5IMIWFpnNokjRH76RYRZAcx0jP0V5/GfNNTi5QsEU98en0SiXHQGXnROiHpRUDXTl8FmJORjwXc0AjrEMuQ2FDJDmAIlKUSLhjbIiKw3iaqp5TVyXuz0ZMYBhnqhcwqULqtFSuIKpaW8FgF8QJfP2frADf4kKZG1bQ99MrRrb2A="}
	url = 'https://www.vavoo.tv/api/box/ping2'
	req = _cache(url, 300, 1, post=vec)
	signed = req['response'].get('signed')
	return signed

def yesno(heading, line1, line2='', line3='', nolabel='', yeslabel=''):
	if PY3:return xbmcgui.Dialog().yesno(heading, line1+"\n"+line2+"\n"+line3, nolabel, yeslabel)
	else:return xbmcgui.Dialog().yesno(heading, line1,line2,line3, nolabel, yeslabel)
	
def ok(heading, line1, line2='', line3=''):
	if PY3:return xbmcgui.Dialog().ok(heading, line1+"\n"+line2+"\n"+line3)
	else:return xbmcgui.Dialog().ok(heading, line1,line2,line3)

def save_to_file(content, filename, path, raw=False):
	"""
	dump json and save to *filename in *path
	"""
	if not os.path.exists(path):
		os.makedirs(path)
	text_file_path = os.path.join(path, filename + ".txt")
	text_file = io.open(text_file_path, "w", encoding="utf-8")
	if not raw:
		json.dump(content, text_file)
	else:
		text_file.write(content)
	text_file.close()

def read_from_file(path, raw=False):
	"""
	return data from file with *path
	"""
	if not os.path.exists(path):
		return False
	try:
		f =  io.open(path, "r", encoding="utf-8")
		logger.debug("opened textfile %s." % (path))
		if not raw:
			result = json.load(f)
		else:
			result = f.read()
		f.close()
		return result
	except Exception:
		logger.debug("failed to load textfile: " + path)
		return False

def get_http(url, headers, post=""):
	succeed = 0
	while (succeed < 2) :
		try:
			if post: request = requests.post(url, headers=headers, data=post)
			else: request = requests.get(url, headers=headers)
			return request.text
		except Exception as e:
			logger.debug('get_http: could not get data from %s' % url)
			xbmc.sleep(500)
			succeed += 1
	return None

def _cache(url="", cache_time=7.0, cache_mode=0, post="", filename="", folder="cache", headers={'User-agent': 'VAVOO/2.6'}):
	"""
	get JSON response for *url, makes use of prop and file cache.
	cache_mode:
		0 = cache in days
		1 = cache in seconds
		2 = store forever
	"""
	now = time.time()
	if filename:
		hashed_url = filename
	else:
		hashed_url = hashlib.md5(url.encode("utf-8", "ignore")).hexdigest()
	cache_path = translate_path(profilePath, folder)
	cache_seconds = int(cache_time) if cache_mode == 0 else int(cache_time * 86400.0)
	if not cache_time:
		home.clearProperty(hashed_url)
		home.clearProperty(hashed_url + "_timestamp")
	prop_time = home.getProperty(hashed_url + "_timestamp")
	if prop_time and ((now - float(prop_time) < cache_seconds) or cache_mode==2):
		try:
			prop = json.loads(home.getProperty(hashed_url))
			return prop
		except Exception as e:
			logger.debug("could not load prop data for %s, Error=%s" % (url,e))
			pass
	path = os.path.join(cache_path, hashed_url + ".txt")
	if os.path.exists(path) and ((now - os.path.getmtime(path)) < cache_seconds):
		results = read_from_file(path)
		logger.debug("loaded file for %s. time: %f" % (url, time.time() - now))
	else:
		if filename == "":
			response = get_http(url, headers, post)
		try:
			if filename != "": results = url
			else:
				results = json.loads(response)
				logger.debug("download %s. time: %f" % (url, time.time() - now))
			save_to_file(results, hashed_url, cache_path)
		except Exception as e:
			logger.error(e)
			if filename != "":
				logger.debug("Exception: Could not get new JSON data from %s. Tryin to fallback to cache" % url)
				logger.debug(response)
			results = read_from_file(path) if os.path.exists(path) else []
	#if not results:
		#logger.debug("could not load prop data for %s" % (url))
		#return None
	home.setProperty(hashed_url + "_timestamp", str(now))
	home.setProperty(hashed_url, json.dumps(results))
	return results

def get_data(params):
	query = params.get("query")
	p=int(params.get("p",1))
	if query:
		_id = params.get("id").replace("series","tv")
		url = "%ssearch/%s?api_key=%s&language=de&query=%s&page=%s"%(tmdburl,_id, api_key,quote(query), p)
		return _cache(url, 14)
	today=datetime.now().date()
	t, i=params.get("id").replace("series","tv").split(".")
	s=int(params.get("s", 0))
	e=int(params.get("e", 0))
	urlparams = {"api_key": api_key,"language": "de", "region": "DE"}
	if i not in ["now_playing","top_rated","popular","on_tv","trending_day","trending_week"]:
		urlparams.update({"include_video_language": "en,null,de", "include_image_language": "en,null,de"})
	release="release_date.lte" if t=="movie" else "air_date.lte"
	count = 300 if t == "movie" else 150
	if i =="trending_day":
		urlparams.update({"page":p})
		url = "%strending/%s/day" %(tmdburl, t)
	elif i == "trending_week":
		urlparams.update({"page":p})
		url = "%strending/%s/week" %(tmdburl, t)
	elif i =="now_playing":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc","include_video":"true","release_date.gte":today-timedelta(days=41),"release_date.lte":today+timedelta(days=1),"with_release_type":3,"page":p})
	elif i == "popular":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc",release:today,"page":p})
	elif i == "top_rated":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"vote_average.desc",release:today,"vote_count.gte":count,"page":p})
	elif i == "on_tv":
		url = "%sdiscover/%s" % (tmdburl, t)
		urlparams.update({"sort_by":"popularity.desc","air_date.gte":today,"air_date.lte":today+timedelta(days=64),"page":p})
	elif t == "movie":
		url = "%smovie/%s" % (tmdburl, i)
		urlparams.update({"append_to_response":"credits,external_ids,videos,keywords,release_dates,alternative_titles"})
	#elif e != 0:
		#url = "%stv/%s/season/%s/episode/%s" % (tmdburl, i, s, e)
		#urlparams.update({"append_to_response":"credits,external_ids,videos"})
	elif (e != 0) or (s != 0):
		url = "%stv/%s/season/%s" % (tmdburl, i, s)
		urlparams.update({"append_to_response":"credits,external_ids,videos,alternative_titles"})
	#elif t=="tv":
	else:
		url = "%stv/%s" % (tmdburl, i)
		urlparams.update({"append_to_response":"credits,external_ids,videos,keywords,content_ratings,alternative_titles"})
	#elif t=="person":
		#url = "%sperson/%s" % (tmdburl, i)
		#urlparams.update({"append_to_response":"tv_credits,movie_credits,combined_credits,tagged_images"})
	url = "%s?%s" % (url, urlencode(urlparams))
	response = _cache(url, 14)
	return response

def getIcon(name, original=False):
	if not name:
		return "DefaultFolder.png"
	if "/" in name:
		return tmdbimg % ("original" if original else "w342", name)
	icon = translate_path(addonPath, "resources", "art", "%s.png"%name)
	if os.path.exists(icon):
		return icon
	return "DefaultFolder.png"

def getPluginUrl(params):
	return sys.argv[0] + '?' + urlencode(params)
	
def genrelist(params):
	if "movie" in params["id"]:
		return _cache("%sgenre/movie/list?api_key=%s&language=de"%(tmdburl, api_key), 14)["genres"]
	return _cache("%sgenre/tv/list?api_key=%s&language=de"%(tmdburl, api_key), 14)["genres"]