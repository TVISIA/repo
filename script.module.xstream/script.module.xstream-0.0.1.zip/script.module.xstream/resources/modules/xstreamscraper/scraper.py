# -*- coding: utf-8 -*-
import os, sys, xbmc, xbmcplugin, xbmcgui, xbmcaddon, requests, urllib3, re, six, json, xbmcvfs, os
from six.moves.urllib.parse import urlencode, parse_qsl, urlsplit, urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed
translatePath = xbmc.translatePath if six.PY2 else xbmcvfs.translatePath
sys.path.append(translatePath("special://home/addons/script.module.xstream/resources/modules/xstreamscraper"))
from resources.lib import tools, utils, config, common
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui
from resources.lib.handler.pluginHandler import cPluginHandler
from resources.lib import settings
settings.init()
sourcesFolder = os.path.join(xbmcaddon.Addon("plugin.video.xstream").getAddonInfo("path"), "sites")
sys.path.append(sourcesFolder)
urllib3.disable_warnings()
session = requests.session()
dialog = xbmcgui.DialogProgress()

def showFailedNotification(msg="Keine Streams gefunden"):
	tools.logger.info(msg)
	xbmc.executebuiltin("Notification(%s,%s,%s,%s)" % ("xStream Scraper",msg,5000,utils.addonInfo("icon")))
	o = xbmcgui.ListItem(xbmc.getInfoLabel("ListItem.Label"))
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, o)

def cleantitle(title):
	a = tools.cParser.replace("(s\d\de\d\d|staffel \d+-\d+|\((\d{4})\))", "", title.lower())
	return tools.cParser.replace("( |-|:)", "", a)

def get_episodes(sources, s, e):
	episoden = []
	for count, source in enumerate(sources, 1):
		try:
			site = source["site"]
			dialog.update(int(count * 25 /len(sources)+50), "Filtere Seite %s..." % site)
			if dialog.iscanceled(): return
			tools.logger.info("Filtere %s" % site)
			for result in plugin(source):
				if "pisode" in result.keys() or result.get("mediaType") == "episode":
					for a in result.keys():
						if "pisode" in a:
							episode = tools.cParser.replace("[^0-9]", "", result[a])
							if episode and int(episode) == int(e):
								episoden.append(result)
				else:
					season = result.get("season")
					if season and int(season) == int(s):
						for results in plugin(result):
							if "pisode" in results.keys() or results.get("mediaType") == "episode":
								for b in results.keys():
									if "pisode" in b:
										episode = tools.cParser.replace("[^0-9]", "", results[b])
										if episode and int(episode) == int(e):
											episoden.append(results)
		except Exception as e:
			tools.logger.error(e)
			import traceback
			tools.logger.debug(traceback.format_exc())
	return episoden
	
def get_hosters(sources, isSerie, season, episode):
	newsources, hosters = sources, []
	if isSerie: newsources = get_episodes(sources, season, episode)
	for count, source in enumerate(newsources, 1):
		site = source["site"]
		if dialog.iscanceled(): return
		dialog.update(int(count * 25 /len(newsources)+75), "Suche nach Hostern auf %s" % source["site"])
		p = plugin(source, True)
		if p:
			function = p[-1]
			del p[-1]
			for a in p:
				a["site"] = site
				a["function"] = function
				if a not in hosters:
					hosters.append(a)
	dialog.close()
	return hosters

def _pluginSearch(pluginEntry, sSearchText, oGui):
	try:
		plugin = __import__(pluginEntry["id"], globals(), locals())
		function = getattr(plugin, "_search")(oGui, sSearchText)
	except Exception as e:
		tools.logger.error(pluginEntry["name"] + ": search failed, Error = %s" % e)
		import traceback
		tools.logger.debug(traceback.format_exc())

def plugin(source, force = False):
	settings.aDirectory = []
	settings.urlparams = source
	link = source.get("link")
	site = source.get("site")
	function = source.get("function")
	try:
		b = __import__(site)
		if link:
			return getattr(b, function)(link)
		else: function = getattr(b, function)()
		if not force and not function: function = settings.aDirectory
		return function
	except Exception as e:
		import traceback
		tools.logger.error(traceback.format_exc())

def searchGlobal(sSearchText, searchtitles, isSerie, _type, _id, season, episode, searchYear):
	multi = 25 if isSerie else 50
	aPlugins = []; sources = []; oGui = cGui(); oGui.globalSearch = True; settings.collectMode = True; i = 0; ntitle =""
	aPlugins = cPluginHandler().getAvailablePlugins()
	dialog.create(cConfig().getLocalizedString(30122), cConfig().getLocalizedString(30123))
	numPlugins = len(aPlugins)
	if numPlugins == 0:
		return showFailedNotification("keine Plugins aktiviert")
	with ThreadPoolExecutor(numPlugins) as executor:
		future_to_url = {executor.submit(_pluginSearch, pluginEntry, sSearchText, oGui):pluginEntry["name"] for pluginEntry in aPlugins}
		for future in as_completed(future_to_url):
			name = future_to_url[future]
			if dialog.iscanceled(): return
			tools.logger.info("Searching for %s at %s" % (sSearchText, name))
			percent = int(i * 25 / numPlugins)
			dialog.update(percent, "%s %s" % (name, cConfig().getLocalizedString(30125)))
			i+=1
	settings.collectMode = False
	total = len(oGui.searchResults)
	if total == 0:
		return showFailedNotification("Nichts gefunden")
	for count, result in enumerate(oGui.searchResults, 1):
		skip = "Ok"
		
		def set_skip(msg):
			nonlocal skip
			if skip == "Ok":
				skip = msg
				
		title, originaltitle, language, quality, mediaType, year = cleantitle(result.get("title")), result.get("title"), result.get("language"), result.get("quality"), result.get("mediaType"), result.get("year")
		if dialog.iscanceled(): return
		if language and language.lower() not in ["ger", "de", "deutsch"]: set_skip(" Wrong Language")
		if isSerie and mediaType == "movie": set_skip(" Wrong Media")
		if isSerie:
			isMatch, found = tools.cParser.parseSingleResult(title, "(season\d+|staffel\d+)")
			if isMatch:
				title = title.replace(found, "")
				ok, aMatches = tools.cParser.parseSingleResult(found, "\d+")
				if ok and int(season) != int(aMatches) : set_skip(" Wrong Season")
		if not isSerie and mediaType and mediaType  in ["tvshow", "series", "episode", "season"] : set_skip(" Wrong Media")
		if not isSerie and year and int(searchYear) !=0 and int(year) != int(searchYear): set_skip(" Wrong Year")
		if utils.api_key:
			if title not in searchtitles: set_skip(" Wrong Name")
		elif title not in cleantitle(sSearchText): set_skip(" Wrong Name")
		if "filmpalast" in result.get("site"):
			if ntitle == title: set_skip(" Duplicate")
			else: ntitle = title
		dialog.update(int(count*multi/total + 25), "%s %s %s\n%s: %s" % (count, cConfig().getLocalizedString(30128), total, skip, originaltitle))
		if skip == "Ok": sources.append(result)
	return sources

def play(_type, _id, season, episode):
	data = utils.get_data({"id":"%s.%s" % (_type, _id)})
	if _type == "tv": isSerie, name, releaseDate = True, data["name"], data["first_air_date"]
	else: isSerie, name, releaseDate = False, data["title"], data["release_date"]
	searchYear=int(releaseDate[:4])
	results = data.get("alternative_titles", {}).get("results")
	searchtitles = [a["title"] for a in results] if results else []
	searchtitles.append(name)
	titles = [cleantitle(a) for a in searchtitles]
	sources = searchGlobal(name, titles, isSerie, _type, _id, season, episode, searchYear)
	if not sources: return showFailedNotification("keine Quellen")
	with open("/sdcard/test/all/sources.json", "w") as writefile:
		json.dump(sources, writefile, indent=4)
	hosters = get_hosters(sources, isSerie, season, episode)
	if not hosters: return showFailedNotification("keine Hoster")
	with open("/sdcard/test/all/hosters.json", "w") as writefile:
		json.dump(hosters, writefile, indent=4)
	total = len(hosters)
	dialog.create(cConfig().getLocalizedString(30122), "Teste Streams")
	for count, k in enumerate(hosters, 1):
		if dialog.iscanceled(): return
		dialog.update(int(count/total*100), "Teste Stream %s/%s" % (count, total))
		import resolveurl as resolver
		try:
			if k.get("resolved"):
				url = k["link"]
			else:
				stream = plugin(k, True)[0]
				url =  resolver.resolve(stream["streamUrl"])
			if isinstance(url, bool):
				raise Exception("kein Link")
			headers = {}; params = {}
			newurl = url
			if "|" in newurl:
				newurl, headers = newurl.split("|")
				headers = dict(parse_qsl(headers))
			if "?" in newurl:
				newurl, params = newurl.split("?")
				params = dict(parse_qsl(params))
			res = session.get(newurl, headers=headers, params=params, stream=True)
			if not res.ok: raise Exception("Kann Seite nicht erreichen")
			if "text" in res.headers.get("Content-Type","text"): raise Exception("Keine Videodatei")
			else:
				tools.logger.info("Spiele :%s" % url)
				return _play(url)
		except Exception as e:
			tools.logger.error(e)
			import traceback
			tools.logger.debug(traceback.format_exc())
		finally:
			del(resolver)
	dialog.close()
	return showFailedNotification()

def _play(url):
	dialog.close()
	o = xbmcgui.ListItem(xbmc.getInfoLabel("ListItem.Label"))
	o.setPath(url)
	o.setProperty("IsPlayable", "true")
	if ".m3u8" in url:
		if six.PY2: o.setProperty("inputstreamaddon", "inputstream.adaptive")
		else: o.setProperty("inputstream", "inputstream.adaptive")
		o.setProperty("inputstream.adaptive.manifest_type", "hls")
	xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, o)