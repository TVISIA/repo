# -*- coding: utf-8 -*-
if __name__ == '__main__':
	import sys
	from resources.lib import utils
	params = dict(utils.parse_qsl(sys.argv[2][1:]))
	tv = params.get("name")
	action = params.pop("action", False)
	if tv:
		from resources.lib import vjlive
		vjlive.livePlay(tv)
	elif action:
		if action == "choose":
			from resources.lib import vjlive
			vjlive.choose()
		elif action == "channels":
			from resources.lib import vjlive
			vjlive.channels()
		elif action == "settings":
			utils.addon.openSettings(sys.argv[1])
		elif action == "favchannels":
			from resources.lib import vjlive
			vjlive.favchannels()
		elif action == "addTvFavorit":
			from resources.lib import vjlive
			vjlive.addtvfavorit(params["channel"])
		elif action == "delTvFavorit":
			from resources.lib import vjlive
			vjlive.deltvfavorit(params["channel"])
		else:
			from resources.lib import vjackson
			getattr(vjackson, "_%s" % action)(params)
	from resources.lib import vjackson
	vjackson._index(params)