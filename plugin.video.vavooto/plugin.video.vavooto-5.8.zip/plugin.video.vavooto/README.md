# plugin.video.vavooto

1. vjackson.info/live2/index
Name:    vjackson.info
Addresses:  2606:4700:3036::ac43:bd1f
          2606:4700:3035::6815:392a
          104.21.57.42
          172.67.189.31
          
2. www2.vjackson.info/live2/index
Name:    www2.vjackson.info
Addresses:  2606:4700:3035::6815:392a
          2606:4700:3036::ac43:bd1f
          172.67.189.31
          104.21.57.42
          
3. www2.vavoo.to/live2/index
Name:    www2.vavoo.to
Addresses:  2606:4700:3035::6815:3ae2
          2606:4700:3032::ac43:d19e
          172.67.209.158
          104.21.58.226